/*   SPDX-License-Identifier: BSD-3-Clause
 *   Copyright (c) Intel Corporation.
 *   All rights reserved.
 */

#ifndef SPDK_INTERNAL_URING_H
#define SPDK_INTERNAL_URING_H

#include <liburing.h>

#endif /* SPDK_INTERNAL_URING_H */
